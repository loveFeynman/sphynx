(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[19],{1595:function(n,p){}}]);
//# sourceMappingURL=19.7a82afa9.chunk.js.map