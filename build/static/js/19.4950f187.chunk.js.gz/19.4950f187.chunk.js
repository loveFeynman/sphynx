(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[19],{1596:function(n,p){}}]);
//# sourceMappingURL=19.4950f187.chunk.js.map