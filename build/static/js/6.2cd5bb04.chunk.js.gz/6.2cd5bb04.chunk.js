(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[6],{1602:function(n,p){}}]);
//# sourceMappingURL=6.2cd5bb04.chunk.js.map