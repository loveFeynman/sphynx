(this["webpackJsonppancake-frontend"]=this["webpackJsonppancake-frontend"]||[]).push([[6],{1600:function(n,p){}}]);
//# sourceMappingURL=6.62695978.chunk.js.map